import { bootstrap } from '@lirx/dom';
import { GuessTheNumber } from './guess-the-number/guess-the-number.component';

export function guessTheNumberExample() {
  bootstrap(GuessTheNumber);
}
