import { signal, ISignal, computed } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, Component } from '@lirx/dom';


// @ts-ignore
import html from './guess-the-number.component.html?raw';
// @ts-ignore
import style from '../guess-the-number.component.scss?inline';

/**
 * COMPONENT: 'app-guess-the-number'
 **/

interface ITemplateData {
  readonly inputValue: ISignal<string>;
  readonly onInput: (event: Event) => void;
  readonly onFormSubmit: (event: Event) => void;

  readonly items: ISignal<IGuessTheNumberItemsList>;

  readonly removeItem: (item: IGuessTheNumberItem) => void;
}

export const GuessTheNumber = new Component({
  name: 'app-guess-the-number',
  template: compileReactiveHTMLAsComponentTemplate({ html }),
  styles: [compileStyleAsComponentStyle(style)],
  templateData: (): ITemplateData => {
    const numberToGuess = Math.floor(Math.random() * 100);
    const inputValue = signal<number>(Number.NaN);

    const inputNumber = computed(() => Number(inputValue()))

    const onInput = (event: Event): void => {
      inputValue.set((event.target as HTMLInputElement).value);
    };

    const onFormSubmit = (event: Event): void => {
      event.preventDefault();

      const value = inputValue().trim();

      if (value !== '') {
        addItem(value);
      }

      inputValue.set('');
    };

    return {
      inputValue,
      onInput,
      onFormSubmit,
      items,
      removeItem,
    };
  },
});
